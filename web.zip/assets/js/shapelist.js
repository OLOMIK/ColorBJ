var ksztalty = [
    "<svg xmlns=\"http://www.w3.org/2000/svg\" style=\"color: #fff;\" width=\"32\" height=\"32\" viewBox=\"0 0 24 24\"><path fill=\"currentColor\" d=\"M11.5 3a9.5 9.5 0 1 1 0 19a9.5 9.5 0 0 1 0-19Zm0 1a8.5 8.5 0 1 0 0 17a8.5 8.5 0 0 0 0-17Z\"/></svg>",
    "<svg xmlns=\"http://www.w3.org/2000/svg\" style=\"color: #fff;\" width=\"32\" height=\"32\" viewBox=\"0 0 24 24\"><path fill=\"currentColor\" d=\"m6.593 21l-4.905-8.494L6.6 4h9.808l4.908 8.5l-4.908 8.5H6.593ZM15.83 5H7.177l-4.334 7.506L7.17 20h8.66l4.33-7.5L15.83 5Z\"/></svg>",
    "<svg xmlns=\"http://www.w3.org/2000/svg\" style=\"color: #fff;\" width=\"32\" height=\"32\" viewBox=\"0 0 24 24\"><path fill=\"currentColor\" d=\"M3 16.011V8.98L7.98 4h7.04L20 8.98v7.046L15.025 21H7.99L3 16.011ZM8.393 5L4 9.393v6.204L8.403 20h6.208L19 15.611V9.393L14.607 5H8.393Z\"/></svg>",
    "<svg xmlns=\"http://www.w3.org/2000/svg\" style=\"color: #fff;\" width=\"32\" height=\"32\" viewBox=\"0 0 24 24\"><path fill=\"currentColor\" d=\"M2.586 12.5L11.5 3.586l8.914 8.914l-8.914 8.914L2.586 12.5ZM11.5 5L4 12.5l7.5 7.5l7.5-7.5L11.5 5Z\"/></svg>",
    "<svg xmlns=\"http://www.w3.org/2000/svg\" style=\"color: #fff;\" width=\"32\" height=\"32\" viewBox=\"0 0 24 24\"><path fill=\"currentColor\" fill-rule=\"evenodd\" d=\"M3 4h17v17H3V4Zm1 1v15h15V5H4Z\"/></svg>",
    "<svg xmlns=\"http://www.w3.org/2000/svg\" style=\"color: #fff;\" width=\"32\" height=\"32\" viewBox=\"0 0 24 24\"><path fill=\"currentColor\" d=\"M1 21L11.5 2.813L22 21H1Zm19.268-1L11.5 4.813L2.732 20h17.536Z\"/></svg>"
];
